Theme Name: Tiny Forge Child
Theme URI: http://mtomas.com/1/tiny-forge-free-mobile-first-wordpress-theme  
Author: Tomas Mackevicius  
Author URI: http://mtomas.com  
Contributors: TomasM  
Version: 1.5.3  
Requires at least: 3.6  
Tested up to: 3.8  
Copyright: based on theme Twenty Twelve by WordPress.org  
License: GNU General Public License v2 or later  
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Quick overview of main theme features
=====================================

- All features that come with Tiny Forge theme
- LESS dynamic stylesheet language support! Welcome to rapid development age - change the look and feel of your site in minutes!
- Search field in the top menu area (ported from Twenty Thirteen theme)

Tips and Tricks
===============

1. In order to see search icon in the top menu, you have to select that menu as a Primary Menu (Admin Panel Menu > Appearance > Menus > Primary Menu check box at the bottom right). To assign menu as Primary, first you have to create it. If menu is not created yet, see the turorial how to do it: http://www.bobwp.com/create-navigation-menus-wordpress/

2. For more information please check readme.txt of Tiny Forge theme.